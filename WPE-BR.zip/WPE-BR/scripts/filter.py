data = data # data contain the request/response
monitor = 1 # 0=hidden, 1=displayd
monitor_color = 0 # 0=black, 1=dark_green, 2=red

import re

print 1234
monitor_color=2